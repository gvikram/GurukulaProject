package Test.Gurukula;


import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;
import org.testng.Assert;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import com.org.gurukula.common.ConfigValues;
import com.org.gurukula.common.DriverConfig;
import com.org.gurukula.pages.BranchPage;
import com.org.gurukula.pages.LoginPage;

public class BranchPageTest extends DriverConfig{
	
	final static Logger logger = LoggerFactory.getLogger(LoginPage.class);
	
	/**
	 *  TC - branch_001	Verify Branch title
	 *  
	 */
	@Parameters ("branchTitle")
	@Test (groups={"Branch", "Regression"})
	public void branch_001 (@Optional ("Branches") String branchTitle){
		try{
			logger.info("TC execution started - branch_001	Verify Branch title");
			LoginPage loginpage = 
				PageFactory.initElements(getDriver(), LoginPage.class);
			BranchPage branchpage = 
				PageFactory.initElements(getDriver(), BranchPage.class);		
			loginpage.openGurukula();
			loginpage.login(ConfigValues.adminUsername, ConfigValues.adminPassword);
			branchpage.selectBranchPage();
			Assert.assertTrue(branchpage.verifyBranchTitle(branchTitle));			
			logger.info("TC execution completed - branch_001	Verify Branch title");
		}catch (Exception e) {
			logger.error("TC failed - branch_001	Verify Branch title" + e.toString());
		}	
	}

	
	/**
	 * TC - branch_002	Verify create new branch
	 * @param branchName 
	 * @param branchCode 
	 */
	@Parameters ({"branchName", "branchCode"})
	@Test (groups={"Branch", "Smoke", "Regression"})
	public void branch_002 (@Optional ("BranchOne") String branchName, @Optional ("12") String branchCode) {
		try{
			logger.info("TC execution started - branch_002	Verify create new branch");
			LoginPage loginpage = 
					PageFactory.initElements(getDriver(), LoginPage.class);
			BranchPage branchpage = 
					PageFactory.initElements(getDriver(), BranchPage.class);		
			loginpage.openGurukula();
			loginpage.login(ConfigValues.adminUsername, ConfigValues.adminPassword);
			branchpage.selectBranchPage();
			//Delete previously exists Branches
			branchpage.deleteAllBranches();
			//Create new branch
			branchpage.createNewBranch (branchName, branchCode);
			Assert.assertTrue(branchpage.verifyNewBranchCreated (branchName));	
			branchpage.deleteBranch();			
			logger.info("TC execution completed - branch_002	Verify create new branch");
		} catch (Exception e) {
			logger.error("TC failed - branch_002	Verify create new branch" + e.toString());
		}		
	}
	
	
	/**
	 * TC - branch_003	Verify Branch Search 
	 * @param branchName 
	 */
	@Parameters({"branchName", "branchCode"})
	@Test (groups={"Branch", "Regression"})
	public void branch_003 (@Optional ("BranchOne") String branchName, @Optional ("12") String branchCode) {
		try {
			logger.info("TC execution started - branch_003	Verify Branch Search ");
			LoginPage loginpage = 
					PageFactory.initElements(getDriver(), LoginPage.class);
			BranchPage branchpage = 
					PageFactory.initElements(getDriver(), BranchPage.class);		
			loginpage.openGurukula();
			loginpage.login(ConfigValues.adminUsername, ConfigValues.adminPassword);
			branchpage.selectBranchPage();
			branchpage.createNewBranch (branchName, branchCode);
			Assert.assertTrue(branchpage.verifyNewBranchCreated (branchName));		
			branchpage.searchBranch(branchName);			
			branchpage.deleteBranch();
			logger.info("TC execution completed - branch_003	Verify Branch Search ");
		} catch (Exception e) {
			logger.error("TC failed - branch_003	Verify Branch Search "+e.toString());
		}	
	}
	
	
	/**
	 * TC - branch_004	Verify view branch and click on Back button
	 * @throws InterruptedException 
	 */
	@Parameters({"branchName", "branchCode"})
	@Test (groups={"Branch", "Regression"})
	public void branch_004 (@Optional ("BranchOne") String branchName, @Optional ("12") String branchCode) throws InterruptedException {
		try{
			logger.info("TC execution started - branch_004	Verify view branch and click on Back button ");
			LoginPage loginpage = 
					PageFactory.initElements(getDriver(), LoginPage.class);
			BranchPage branchpage = 
					PageFactory.initElements(getDriver(), BranchPage.class);		
			loginpage.openGurukula();
			loginpage.login(ConfigValues.adminUsername, ConfigValues.adminPassword);
			branchpage.selectBranchPage();
			branchpage.createNewBranch (branchName+"U", branchCode);
			Assert.assertTrue(branchpage.verifyViewBranch(branchName+"U", branchCode));	
			branchpage.deleteBranch();	
			logger.info("TC execution completed - branch_004	Verify view branch and click on Back button ");
	}catch (Exception e) {
		logger.error("TC failed - branch_004	Verify view branch and click on Back button "+e.toString());
	}	
}
		
	
	/**
	 * TC - branch_005	Verify edit branch 
	 */
	@Parameters({"branchName", "branchCode"})
	@Test (groups={"Branch", "Regression"})
	public void branch_005 (@Optional ("BranchOne") String branchName, @Optional ("12") String branchCode) {
		try{
			logger.info("TC execution started - branch_005	Verify edit branch ");
			LoginPage loginpage = 
					PageFactory.initElements(getDriver(), LoginPage.class);
			BranchPage branchpage = 
					PageFactory.initElements(getDriver(), BranchPage.class);		
			loginpage.openGurukula();
			loginpage.login(ConfigValues.adminUsername, ConfigValues.adminPassword);
			branchpage.selectBranchPage();
			branchpage.createNewBranch (branchName, branchCode);
			branchpage.searchBranch(branchName);
			Assert.assertTrue(branchpage.editBranchName(branchName+"Updated"));		
			branchpage.deleteBranch();
			logger.info("TC execution completed - branch_005	Verify edit branch ");
	}catch (Exception e) {
		logger.error("TC failed - branch_005	Verify edit branch "+e.toString());
	}	
	}
	
	
	/**
	 * TC - Branch_006	Verify delete branch, click on Delete of "confirmation delete" popup 
	 */
	@Parameters({"branchName", "branchCode"})
	@Test (groups={"Branch", "Regression"})
	public void branch_006 (@Optional ("BranchOne") String branchName, @Optional ("12") String branchCode) {
		try{
			logger.info("TC execution started - branch_006	Verify delete branch ");
			LoginPage loginpage = 
					PageFactory.initElements(getDriver(), LoginPage.class);
			BranchPage branchpage = 
					PageFactory.initElements(getDriver(), BranchPage.class);		
			loginpage.openGurukula();
			loginpage.login(ConfigValues.adminUsername, ConfigValues.adminPassword);
			branchpage.selectBranchPage();
			branchpage.createNewBranch (branchName+"V", branchCode);
			branchpage.searchBranch(branchName+"V");	
			//Delete previously exists Branches
			branchpage.deleteAllBranches();	
			logger.info("TC execution completed - branch_006	Verify delete branch ");
	}catch (Exception e) {
		logger.error("TC failed - branch_006	Verify delete branch"+e.toString());
	}	
	}
	
		
	/**
	 * TC - Branch_007	Verify enter two chars in Create Branch Name field
	 */
	@Parameters({"branchNameTwoChars", "minLengthBranchNameErrMsg"})
	@Test (groups={"Branch", "Regression"})
	public void branch_007 (@Optional ("Br") String branchNameTwoChars, @Optional ("This field is required to be at least 5 characters.") String minLengthBranchNameErrMsg) {
		try{
			logger.info("TC execution started - branch_007	Verify enter two chars in Create Branch Name field ");			
			LoginPage loginpage = 
					PageFactory.initElements(getDriver(), LoginPage.class);
			BranchPage branchpage = 
					PageFactory.initElements(getDriver(), BranchPage.class);
			loginpage.openGurukula();
			loginpage.login(ConfigValues.adminUsername, ConfigValues.adminPassword);
			branchpage.selectBranchPage();	
			branchpage.clickOnCreateNewBranchButton();
			branchpage.enterBranchName(branchNameTwoChars);
			branchpage.clickOnSave();
			Assert.assertTrue(branchpage.verifyAtLeast5CharsErrMsg(minLengthBranchNameErrMsg));	
			logger.info("TC execution completed - branch_007	Verify enter two chars in Create Branch Name field ");
	}catch (Exception e) {
		logger.error("TC failed - branch_007 Verify enter two chars in Create Branch Name field"+e.toString());
	}	
	}
	
	
	/**
	 * TC - Branch_008	Verify alpha numeric in Create Branch Name field
	 */
	@Parameters ({"branchNameAlphaNumeric", "alphaNumericBranchNameErrMsg"})
	@Test (groups={"Branch", "Regression"})
	public void branch_008 (@Optional ("Branch_123") String branchNameAlphaNumeric, @Optional ("This field should follow pattern ^[a-zA-Z\\s]*$.") String alphaNumericBranchNameErrMsg) {
		try{
			logger.info("TC execution started - branch_008	Verify alpha numeric in Create Branch Name field ");			
			LoginPage loginpage = 
					PageFactory.initElements(getDriver(), LoginPage.class);
			BranchPage branchpage = 
					PageFactory.initElements(getDriver(), BranchPage.class);
			loginpage.openGurukula();
			loginpage.login(ConfigValues.adminUsername, ConfigValues.adminPassword);
			branchpage.selectBranchPage();	
			branchpage.clickOnCreateNewBranchButton();
			branchpage.enterBranchName(branchNameAlphaNumeric);
			branchpage.clickOnSave();
			Assert.assertTrue(branchpage.verifyValidationPatternErrMsg(alphaNumericBranchNameErrMsg));
			logger.info("TC execution completed - branch_008	Verify alpha numeric in Create Branch Name field ");
	}catch (Exception e) {
		logger.error("TC failed - branch_008 Verify alpha numeric in Create Branch Name field"+e.toString());
	}	
	}	
	
	/**
	 * TC - Branch_009	Verify enter 1 letter in Create Branch code field
	 */
	@Parameters ({"branchCodeLetter", "minLengthCodeErrMsg"})
	@Test (groups={"Branch", "Regression"})
	public void branch_009 (@Optional ("1") String branchCodeLetter, @Optional ("This field is required to be at least 2 characters.") String minLengthCodeErrMsg) {
		try{
			logger.info("TC execution started - branch_009	Verify enter 1 letter in Create Branch code field");			
			LoginPage loginpage = 
					PageFactory.initElements(getDriver(), LoginPage.class);
			BranchPage branchpage = 
					PageFactory.initElements(getDriver(), BranchPage.class);
			loginpage.openGurukula();
			loginpage.login(ConfigValues.adminUsername, ConfigValues.adminPassword);
			branchpage.selectBranchPage();	
			branchpage.clickOnCreateNewBranchButton();
			branchpage.enterBranchCode(branchCodeLetter);
			branchpage.clickOnSave();
			Assert.assertTrue(branchpage.verifyAtLeast2CharsErrMsg(minLengthCodeErrMsg));	
			branchpage.clickOnCancel();			
			logger.info("TC execution completed - branch_009	Verify enter 1 letter in Create Branch code field");
	}catch (Exception e) {
		logger.error("TC failed - branch_009 Verify enter 1 letter in Create Branch code field"+e.toString());
	}	
	}	
			
	}
