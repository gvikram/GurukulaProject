package Test.Gurukula;

import java.util.Random;

import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import com.org.gurukula.common.ConfigValues;
import com.org.gurukula.common.DriverConfig;
import com.org.gurukula.pages.AccountPage;
import com.org.gurukula.pages.BranchPage;
import com.org.gurukula.pages.LoginPage;
import com.org.gurukula.pages.StaffPage;

public class StaffPageTest extends DriverConfig{
	
	final static Logger logger = LoggerFactory.getLogger(LoginPage.class);	
	
	/**
	 * TC - staff_001	Verify Staff page title
	 */
	@Parameters("staffPageTitle")
	@Test (groups={"Staff", "Regression"})
	public void staff_001 (@Optional ("Staffs") String staffPageTitle){		
		try{
			logger.info("TC execution started - staff_001	Verify Staff page title");
			LoginPage loginpage = 
					PageFactory.initElements(getDriver(), LoginPage.class);
			StaffPage staffpage = 
					PageFactory.initElements(getDriver(), StaffPage.class);	
			loginpage.openGurukula();
			loginpage.login(ConfigValues.adminUsername, ConfigValues.adminPassword);		
			staffpage.verifyStaffTitle(staffPageTitle);
			logger.info("TC execution completed - staff_001	Verify Staff page title");
		} catch (Exception e) {
			logger.error("TC failed - staff_001	Verify Staff page title"+e.toString());
		}		
	}
		
	
	/**
	 * TC - staff_002	Verify create new Staff
	 */
	@Parameters ({"staffName", "staffBranch", "branchName", "branchCode"})
	@Test (groups={"Staff", "Smoke", "Regression"})
	public void staff_002 (@Optional ("StaffOne") String staffName, @Optional ("BranchOne") String staffBranch, @Optional ("BranchOne") String branchName, @Optional ("12") String branchCode) {
		try{
			logger.info("TC execution started - Staff_002	Verify create new Staff");
			LoginPage loginpage = 
					PageFactory.initElements(getDriver(), LoginPage.class);			
			StaffPage staffpage = 
					PageFactory.initElements(getDriver(), StaffPage.class);				
			loginpage.openGurukula();
			loginpage.login(ConfigValues.adminUsername, ConfigValues.adminPassword);			
			staffpage.selectStaffPage();
			//Delete all previous exists Staffs
			staffpage.deleteAllStaffs();
			//Create new staff
			staffpage.createNewStaff(staffName, staffBranch);
			logger.info("TC execution completed - Staff_002	Verify create new Staff");
		} catch (Exception e) {
			logger.error("TC failed - Staff_002	Verify create new Staff"+e.toString());
		}		
	}
	
		
	/**
	 * TC - staff_003	Verify Staff View
	 */
	@Parameters ({"staffName", "staffBranch", "branchName", "branchCode"})
	@Test (groups={"Staff", "Regression"})
	public void staff_003 (@Optional ("StaffOne") String staffName, @Optional ("BranchOne") String staffBranch, @Optional ("BranchOne") String branchName, @Optional ("12") String branchCode) {
		try{
			logger.info("TC execution started - staff_003	Verify Staff View");
			LoginPage loginpage = 
					PageFactory.initElements(getDriver(), LoginPage.class);			
			StaffPage staffpage = 
					PageFactory.initElements(getDriver(), StaffPage.class);				
			loginpage.openGurukula();
			loginpage.login(ConfigValues.adminUsername, ConfigValues.adminPassword);			
			staffpage.selectStaffPage();
			staffpage.createNewStaff(staffName+"U", staffBranch);
			staffpage.viewStaffButton();
			logger.info("TC execution completed - staff_003	Verify Staff View");
		} catch (Exception e) {
			logger.error("TC failed - staff_003	Verify Staff View"+e.toString());
		}	
	}
	
	
	/**
	 * TC - staff_004	Verify Cancel of create new staff
	 */
	@Test (groups={"Staff", "Regression"})
	public void staff_004 () {
		try{
			logger.info("TC execution started - staff_004	Verify cancel of create new staff");
			LoginPage loginpage = 
					PageFactory.initElements(getDriver(), LoginPage.class);			
			StaffPage staffpage = 
					PageFactory.initElements(getDriver(), StaffPage.class);				
			loginpage.openGurukula();
			loginpage.login(ConfigValues.adminUsername, ConfigValues.adminPassword);			
			staffpage.selectStaffPage();			
			staffpage.clickOnCreateNewStaffButton();
			staffpage.clickOnCancel();
			logger.info("TC execution completed - staff_004	Verify Cancel of create new staff");
		} catch (Exception e) {
			logger.error("TC failed - staff_004	Verify Cancel of create new staff"+e.toString());
		}	
	}
	
	/**
	 * TC - staff_005	Verify Staff view back button
	 */
	@Parameters ({"staffName", "staffBranch", "branchName", "branchCode"})
	@Test (groups={"Staff", "Regression"})
	public void staff_005 (@Optional ("StaffOne") String staffName, @Optional ("BranchOne") String staffBranch, @Optional ("BranchOne") String branchName, @Optional ("12") String branchCode) {
		try{
			logger.info("TC execution started - staff_005	Verify Staff view back button");
			LoginPage loginpage = 
					PageFactory.initElements(getDriver(), LoginPage.class);			
			StaffPage staffpage = 
					PageFactory.initElements(getDriver(), StaffPage.class);	
			BranchPage branchpage = 
					PageFactory.initElements(getDriver(), BranchPage.class);
			loginpage.openGurukula();
			loginpage.login(ConfigValues.adminUsername, ConfigValues.adminPassword);	
			branchpage.selectBranchPage();
			branchpage.createNewBranch (branchName, branchCode);
			staffpage.selectStaffPage();	
			staffpage.createNewStaff(staffName+"V", staffBranch);
			staffpage.searchStaff(staffName+"V");
			staffpage.viewStaffButton();
			staffpage.clickOnViewStaffBackButton();
			staffpage.deleteStaff();
			branchpage.selectBranchPage();
			branchpage.deleteBranch();			
			logger.info("TC execution completed - staff_005	Verify Staff view back button");
		} catch (Exception e) {
			logger.error("TC failed - staff_005	Verify Staff view back button"+e.toString() );
		}	
	}
	
	
	/** 
	 * TC - staff_006	Verify pagination on Staff table
	 */
	@Parameters ({"staffName", "staffBranch", "branchName", "branchCode"})
	@Test (groups={"Staff", "Regression"})
	public void staff_006 (@Optional ("StaffOne") String staffName, @Optional ("BranchOne") String staffBranch, @Optional ("BranchOne") String branchName, @Optional ("12") String branchCode) {	try{
			logger.info("TC execution started - staff_006	Verify pagination on Staff table");			
			int counter = 1;
			char[] alphabets= {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};
			int alphabetsIndex;			
			LoginPage loginpage = 
					PageFactory.initElements(getDriver(), LoginPage.class);
			BranchPage branchpage = 
					PageFactory.initElements(getDriver(), BranchPage.class);
			StaffPage staffpage = 
					PageFactory.initElements(getDriver(), StaffPage.class);				
			loginpage.openGurukula();
			loginpage.login(ConfigValues.adminUsername, ConfigValues.adminPassword);
			branchpage.selectBranchPage();
			branchpage.createNewBranch (branchName, branchCode);
			staffpage.selectStaffPage();		
			
			//Create Staffs
			while (counter<=50)
			{
				Random rnd = new Random();
				alphabetsIndex = rnd.nextInt(25);
				staffpage.createNewStaff(staffName+alphabets[alphabetsIndex], staffBranch);
				counter++;
			}
			staffpage.verifyPagination();
			counter = 1;
			//Delete staffs which are created above
			while (counter<=50)
			{
				staffpage.deleteStaff();
				counter++;
			}
			//Delete Branch
			branchpage.selectBranchPage();
			branchpage.deleteBranch();
			logger.info("TC execution completed - staff_006	Verify pagination on Staff table");
		} catch (Exception e) {
			logger.error("TC failed - staff_006	Verify pagination on Staff table"+e.toString());
		}
	}
	


	/**
	 * TC - staff_007	Verify Staff Edit Save with updated values
	 */
	@Parameters({"updatedStaffName", "staffName", "staffBranch", "branchName", "branchCode"})
	@Test (groups={"Staff", "Regression"})
	public void staff_007 (@Optional ("StaffOneUpdated") String updatedStaffName, @Optional ("StaffOne") String staffName, @Optional ("BranchOne") String staffBranch, @Optional ("BranchOne") String branchName, @Optional ("12") String branchCode) {
		try{
			logger.info("TC execution started - staff_007	Verify Staff Edit Save with updated values");
			LoginPage loginpage = 
					PageFactory.initElements(getDriver(), LoginPage.class);
			BranchPage branchpage = 
					PageFactory.initElements(getDriver(), BranchPage.class);
			StaffPage staffpage = 
					PageFactory.initElements(getDriver(), StaffPage.class);				
			loginpage.openGurukula();
			loginpage.login(ConfigValues.adminUsername, ConfigValues.adminPassword);
			branchpage.selectBranchPage();
			branchpage.createNewBranch (branchName, branchCode);
			staffpage.selectStaffPage();
			staffpage.createNewStaff(staffName+"N", staffBranch);
			staffpage.searchStaff(staffName+"N");
			staffpage.editStaffName();
			staffpage.enterStaffName(updatedStaffName);
			staffpage.clickOnSave();
			logger.info("TC execution completed - staff_007	Verify Staff Edit Save with updated values");
		}catch (Exception e) {
			logger.error("TC failed - staff_007	Verify Staff Edit Save with updated values"+e.toString());
		}		
	}	
	
	/**
	 * TC - staff_008	Verify click on Account - UserSettings page from  Staff page
	 */	 	
	@Test (groups={"Staff", "Regression"})
	public void staff_008 () {			
		try{
			logger.info("TC execution started - staff_008	Verify click on Account - UserSettings page from  Staff page");
			LoginPage loginpage = 
					PageFactory.initElements(getDriver(), LoginPage.class);			
			StaffPage staffpage = 
					PageFactory.initElements(getDriver(), StaffPage.class);	
			AccountPage accountpage =
					PageFactory.initElements(getDriver(), AccountPage.class);				
			loginpage.openGurukula();
			loginpage.login(ConfigValues.adminUsername, ConfigValues.adminPassword);			
			staffpage.selectStaffPage();
			//Delete all previous exists Staffs
			staffpage.deleteAllStaffs();
			accountpage.clickOnAccountMenu();
			accountpage.selectSettingsFromMenu();	
			logger.info("TC execution completed - staff_008	Verify click on Account - UserSettings page from  Staff page");
		} catch (Exception e) {
			logger.error("TC failed - staff_008	Verify click on Account - UserSettings page from  Staff page"+e.toString());
		}		
	}

	
}
